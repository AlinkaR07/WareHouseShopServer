﻿using Microsoft.AspNetCore.Identity;

namespace AspNetCoreApp.DAL.Models
{
    public class User : IdentityUser
    {

    }
}
